﻿using FormsAuthExample.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace FormsAuthExample.Controllers
{
    public class LoginController : Controller
    {
        public ActionResult Login()
    {
        return View();
    }
    [HttpPost]
    public ActionResult Login(User u, string returnUrl)
    {
        if (ModelState.IsValid)
        {
            
            if (u.UserName == "a" && u.passWord == "b")
            {
                FormsAuthentication.SetAuthCookie(u.UserName, false);

                if (!string.IsNullOrEmpty(returnUrl))
                {
                    return Redirect(returnUrl);
                }
                else
                {
                    return RedirectToAction("Index", "Home");
                }
            }
            else
            {
                ModelState.AddModelError("authenticationError", "User name or Password is wrong. Try it again");
            }
        }
        return View(u);
    }

    [Authorize]
    [HttpGet]
    public ActionResult logOut()
    {
        FormsAuthentication.SignOut();
        return RedirectToAction("Login");

    }

}
}