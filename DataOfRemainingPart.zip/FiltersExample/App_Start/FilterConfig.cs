﻿using System.Web;
using System.Web.Mvc;

namespace FiltersExample
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            //global level filter
            //filters.Add(new HandleErrorAttribute());
        }
    }
}
